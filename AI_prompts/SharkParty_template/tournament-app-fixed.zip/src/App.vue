<template>
  <div class="content__main">
    <Tournament />
  </div>
</template>

<script setup>
import Tournament from './components/Tournament.vue'
</script>
